properties([pipelineTriggers([githubPush()])])
def zAgent       = 'ltizosagent'
def myFolder     = 'sampleApplication'
def jobRepo      = "git@github.com:LTIM-Digital-Engineering/Mainframe_DevOps.git"
def pipelineName = "MFDevOps_Pipeline"
def gitCredId    = "Github_PAT"
 
 
pipeline {
	agent  { label zAgent }
	options { skipDefaultCheckout(true) }
 
	environment {
		GIT_TRACE       = 'false'                
		GIT_TRACE_SETUP = 'true'                 
		myL4J         = 'ON'                     
		JAVA_HOME     = '/usr/lpp/java/J17.0_64/'
		_BPX_SHAREAS  = 'NO'
		jobRepo       = "git@github.com:LTIM-Digital-Engineering/Mainframe_DevOps.git"
		myApp        = 'Mainframe_DevOps'
		zAppBuild    = "/u/ibmuser/dbb-zappbuild/build.groovy"
		pdsHLQ       = "IBMUSER.JENKINS.PIPELINE"
}
 
	stages {
		stage('DEBUG') {
            steps {
                echo "==== DEBUG: Entered Jenkinsfile ===="
            }
        }
		stage('init') {
			 steps {
				println '** Init Step: Setting up a Git Env'				
				script {   
					def nodes   = env.jobRepo.split("/")
					env.wkDir   = nodes[1].split(".git")[0]  
                                        nodes = nodes[0].split(":")
					def gitDom  = nodes[1]
					def gitID  = nodes[0].split("@")[1]
				}
			}
		}//stage init
		stage('Cleanup Workspace') {
			steps { 
				deleteDir()
				println "** Cleaned Up Workspace For Project"
			}
		}//stage Cleanup Workspace
		stage('Clone Repository') {
		    steps {
		        script {
		            def srcGitRepo   = env.jobRepo
		            def srcGitBranch = env.BRANCH_NAME ?: 'main'
		            checkout([
		                $class: 'GitSCM',
		                branches: [[name: srcGitBranch]],
		                doGenerateSubmoduleConfigurations: false,
		                submoduleCfg: [],
		                userRemoteConfigs: [[credentialsId: gitCredId, url: env.jobRepo]],
		                extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${env.myApp}"]]
		            ])
		        }
		    }
		}
 
 
 
		stage('Full Build') {
			    steps {
			        script {
			            println '** Building..'
			            sh """
			                pwd
			                ls -l ${env.WORKSPACE}/${env.myApp}/COBOL
			                ${env.DBB_HOME}/bin/groovyz \
			                    -Dlog4j.configurationFile=file:/u/ibmuser/log4j2.properties \
			                    ${env.zAppBuild} \
			                    -w ${env.WORKSPACE} \
			                    -a ${env.myApp} \
			                    -o ${env.WORKSPACE}/buildlogs/build-${env.BUILD_NUMBER} \
			                    -h ${env.pdsHLQ} \
			                    -id ibmuser -pw ltim \
			                    --fullBuild
			            """
			        }
			    }
			}
 
 
		
	}
 
	post {
		always {
			script {
				try {
					println '** Cleanup...'
					sh "if test -f ~/.git-credentials; then /bin/rm ~/.git-credentials; fi"
					} 
				catch ( Exception ex ) {
					println "!** Error in post step"
				}
			}
		}
	}
}
