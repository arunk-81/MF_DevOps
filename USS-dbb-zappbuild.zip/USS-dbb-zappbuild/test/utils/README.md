## Utilities available for test scripts

File | Description
--- | --- 
[testUtilities.groovy](testUtilities.groovy) | Utilities script containing common methods which can be used across build scripts.